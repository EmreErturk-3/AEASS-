

from AEASS import SudokuSolver
import numpy as np
import time
from typing import Dict, List, Tuple
import matplotlib.pyplot as plt
import pandas as pd
from statistics import mean, stdev

def evaluate_algorithm(sudoku: List[List[int]], num_runs: int = 10) -> Dict:
    """
    Evaluate the algorithm by running it multiple times and collecting statistics.
    
    Args:
        sudoku: Input Sudoku puzzle
        num_runs: Number of runs to perform (default: 10)
    
    Returns:
        Dictionary containing evaluation results and statistics
    """
    results = {
        'fitness_values': [],
        'runtimes': [],
        'convergence_history': []
    }
    
    print(f"Running algorithm {num_runs} times...")
    
    for run in range(num_runs):
        print(f"\nRun {run + 1}/{num_runs}")
        start_time = time.time()
        
        # Initialize and run solver
        solver = SudokuSolver(sudoku)
        solution, history = solver.solve()
        
        runtime = time.time() - start_time
        
        # Store results
        results['fitness_values'].append(solver.best_fitness)
        results['runtimes'].append(runtime)
        results['convergence_history'].append(history)
        
        print(f"Fitness: {solver.best_fitness:.4f}")
        print(f"Runtime: {runtime:.2f}s")
    
    return results

def calculate_statistics(results: Dict) -> Dict:
    """Calculate required statistics from the results."""
    stats = {
        'fitness': {
            'mean': mean(results['fitness_values']),
            'std': stdev(results['fitness_values']),
            'best': max(results['fitness_values']),
            'worst': min(results['fitness_values'])
        },
        'runtime': {
            'mean': mean(results['runtimes']),
            'std': stdev(results['runtimes'])
        }
    }
    return stats

def create_results_table(stats: Dict) -> pd.DataFrame:
    """Create a table with the final statistics."""
    data = {
        'Metric': ['Mean', 'Standard Deviation', 'Best', 'Worst'],
        'Fitness': [
            f"{stats['fitness']['mean']:.4f}",
            f"{stats['fitness']['std']:.4f}",
            f"{stats['fitness']['best']:.4f}",
            f"{stats['fitness']['worst']:.4f}"
        ],
        'Runtime (s)': [
            f"{stats['runtime']['mean']:.2f}",
            f"{stats['runtime']['std']:.2f}",
            '-',
            '-'
        ]
    }
    return pd.DataFrame(data)

def plot_results(results: Dict, stats: Dict):
    """Create plots for the results analysis."""
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(20, 6))
    
    # Box plot of fitness values
    ax1.boxplot(results['fitness_values'])
    ax1.set_title('Fitness Distribution')
    ax1.set_ylabel('Fitness Value')
    ax1.grid(True)
    
    # Box plot of runtimes
    ax2.boxplot(results['runtimes'])
    ax2.set_title('Runtime Distribution')
    ax2.set_ylabel('Runtime (seconds)')
    ax2.grid(True)
    
    # Line plot for convergence
    # Calculate mean convergence history
    min_length = min(len(history) for history in results['convergence_history'])
    aligned_histories = [history[:min_length] for history in results['convergence_history']]
    mean_history = np.mean(aligned_histories, axis=0)
    std_history = np.std(aligned_histories, axis=0)
    generations = range(min_length)
    
    ax3.plot(generations, mean_history, 'b-', label='Mean Fitness')
    ax3.fill_between(generations, 
                    mean_history - std_history,
                    mean_history + std_history,
                    alpha=0.2,
                    color='blue',
                    label='±1 Std Dev')
    ax3.set_title('Convergence Process')
    ax3.set_xlabel('Generation')
    ax3.set_ylabel('Fitness')
    ax3.grid(True)
    ax3.legend()
    
    plt.tight_layout()
    plt.show()

def main():
    # Example Sudoku puzzle
    sudoku = [
        [3,0,2,0,0,6,0,0,1],
        [8,0,0,0,0,0,7,0,0],
        [0,0,6,0,0,4,0,0,9],
        [0,0,7,0,0,0,0,0,0],
        [0,0,0,0,5,0,0,0,0],
        [4,6,0,0,0,2,0,9,0],
        [0,4,0,0,0,0,0,1,0],
        [6,8,0,0,0,1,0,0,2],
        [0,2,0,9,5,0,0,0,6]
    ]
    
    # Run evaluation
    results = evaluate_algorithm(sudoku)
    
    # Calculate statistics
    stats = calculate_statistics(results)
    
    # Create and display results table
    results_table = create_results_table(stats)
    print("\nFinal Statistics:")
    print(results_table.to_string(index=False))
    
    # Create and display plots
    plot_results(results, stats)

if __name__ == "__main__":
    main()